console.log("Primeiro programa em JS");

// criei um objeto com 2 campos name e address
let user = { name: "Renato", address: "Rua XPTO" }
// concatenacao dos campos na variavel output
let output = user.name + ", " + user.address;
console.log(output);

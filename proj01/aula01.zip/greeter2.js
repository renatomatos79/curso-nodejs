function greeter(person) {
    return "Hello, " + person;
}
var user = [0, 1, 2];
var output = greeter(user);
console.log(output);

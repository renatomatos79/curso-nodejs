var user = { name: "Renato", address: "Rua XPTO" };
var output = user.name + ", " + user.address;
console.log(output);

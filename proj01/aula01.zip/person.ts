interface Person {
    firstName: string;
    lastName: string;
}

export { Person }